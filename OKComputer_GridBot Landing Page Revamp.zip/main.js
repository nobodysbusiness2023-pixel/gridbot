// GridBot Command Center - Interactive Functionality

document.addEventListener('DOMContentLoaded', function() {
    initializeGridVisualizer();
    initializeTimeline();
    initializeAnimations();
    initializeScrollEffects();
});

// Grid Strategy Visualizer
function initializeGridVisualizer() {
    const chartDom = document.getElementById('gridVisualizer');
    if (!chartDom) return;
    
    const myChart = echarts.init(chartDom, 'dark');
    
    // Generate sample price data with oscillation
    const priceData = [];
    const buyOrders = [];
    const sellOrders = [];
    const gridLevels = [];
    
    let basePrice = 100;
    const gridSpacing = 5;
    const numGrids = 8;
    
    // Generate price movement data
    for (let i = 0; i < 100; i++) {
        basePrice += (Math.random() - 0.5) * 4;
        priceData.push([i, basePrice.toFixed(2)]);
    }
    
    // Generate grid levels
    const currentPrice = priceData[priceData.length - 1][1];
    for (let i = 0; i < numGrids; i++) {
        const level = currentPrice - (gridSpacing * (i + 1));
        gridLevels.push(level);
        
        // Add buy orders below current price
        buyOrders.push([i * 2, level]);
        
        // Add corresponding sell orders
        sellOrders.push([i * 2 + 1, level + gridSpacing]);
    }
    
    const option = {
        backgroundColor: 'transparent',
        grid: {
            left: '10%',
            right: '10%',
            top: '10%',
            bottom: '15%'
        },
        xAxis: {
            type: 'value',
            axisLine: {
                lineStyle: {
                    color: '#374151'
                }
            },
            axisLabel: {
                color: '#9CA3AF'
            },
            splitLine: {
                lineStyle: {
                    color: '#374151',
                    type: 'dashed'
                }
            }
        },
        yAxis: {
            type: 'value',
            axisLine: {
                lineStyle: {
                    color: '#374151'
                }
            },
            axisLabel: {
                color: '#9CA3AF',
                formatter: '${value}'
            },
            splitLine: {
                lineStyle: {
                    color: '#374151',
                    type: 'dashed'
                }
            }
        },
        series: [
            {
                name: 'Price',
                type: 'line',
                data: priceData,
                lineStyle: {
                    color: '#2DD4BF',
                    width: 2
                },
                symbol: 'none',
                smooth: true
            },
            {
                name: 'Buy Orders',
                type: 'scatter',
                data: buyOrders,
                symbol: 'triangle',
                symbolSize: 10,
                itemStyle: {
                    color: '#059669'
                }
            },
            {
                name: 'Sell Orders',
                type: 'scatter',
                data: sellOrders,
                symbol: 'triangle',
                symbolSize: 10,
                itemStyle: {
                    color: '#DC2626'
                }
            }
        ],
        tooltip: {
            trigger: 'axis',
            backgroundColor: '#1F2937',
            borderColor: '#374151',
            textStyle: {
                color: '#F9FAFB'
            },
            formatter: function(params) {
                let result = `Time: ${params[0].data[0]}<br/>`;
                params.forEach(param => {
                    if (param.seriesName === 'Price') {
                        result += `${param.seriesName}: $${param.data[1]}<br/>`;
                    } else if (param.seriesName === 'Buy Orders') {
                        result += `<span style="color: #059669">●</span> Buy Order: $${param.data[1]}<br/>`;
                    } else if (param.seriesName === 'Sell Orders') {
                        result += `<span style="color: #DC2626">●</span> Sell Order: $${param.data[1]}<br/>`;
                    }
                });
                return result;
            }
        },
        legend: {
            data: ['Price', 'Buy Orders', 'Sell Orders'],
            bottom: 0,
            textStyle: {
                color: '#9CA3AF'
            }
        },
        animation: true,
        animationDuration: 1000,
        animationEasing: 'cubicOut'
    };
    
    myChart.setOption(option);
    
    // Animate chart on load
    setTimeout(() => {
        myChart.dispatchAction({
            type: 'showTip',
            seriesIndex: 0,
            dataIndex: priceData.length - 1
        });
    }, 1500);
    
    // Handle window resize
    window.addEventListener('resize', function() {
        myChart.resize();
    });
}

// Timeline Interaction
function initializeTimeline() {
    const timelineItems = document.querySelectorAll('.timeline-item');
    
    timelineItems.forEach(item => {
        item.addEventListener('click', function() {
            // Remove active class from all items
            timelineItems.forEach(i => {
                i.classList.remove('active');
                i.classList.add('bg-gray-800');
                i.classList.remove('bg-gray-700');
                i.classList.remove('border-teal-500');
                i.classList.add('border-gray-600');
                
                // Reset step number colors
                const stepNumber = i.querySelector('.w-8');
                if (stepNumber) {
                    stepNumber.classList.remove('bg-teal-500');
                    stepNumber.classList.add('bg-gray-600');
                }
            });
            
            // Add active class to clicked item
            this.classList.add('active');
            this.classList.remove('bg-gray-800');
            this.classList.add('bg-gray-700');
            this.classList.remove('border-gray-600');
            this.classList.add('border-teal-500');
            
            // Update step number color
            const stepNumber = this.querySelector('.w-8');
            if (stepNumber) {
                stepNumber.classList.remove('bg-gray-600');
                stepNumber.classList.add('bg-teal-500');
            }
            
            // Animate the item
            anime({
                targets: this,
                scale: [1, 1.02, 1],
                duration: 300,
                easing: 'easeOutQuad'
            });
        });
    });
    
    // Auto-cycle through timeline steps
    let currentStep = 1;
    setInterval(() => {
        const nextItem = document.querySelector(`[data-step="${currentStep}"]`);
        if (nextItem) {
            nextItem.click();
        }
        currentStep = currentStep >= 6 ? 1 : currentStep + 1;
    }, 4000);
}

// Initialize Animations
function initializeAnimations() {
    // Animate cards on scroll
    const cards = document.querySelectorAll('.card-hover');
    
    // Initial animation for hero elements
    anime.timeline({
        easing: 'easeOutExpo',
        duration: 1000
    })
    .add({
        targets: '.hero-content h1',
        translateY: [50, 0],
        opacity: [0, 1],
        duration: 800
    })
    .add({
        targets: '.hero-content p',
        translateY: [30, 0],
        opacity: [0, 1],
        duration: 600,
        delay: anime.stagger(100)
    }, '-=600')
    .add({
        targets: '.hero-content button',
        translateY: [20, 0],
        opacity: [0, 1],
        duration: 500,
        delay: anime.stagger(100)
    }, '-=400');
    
    // Feature cards hover animation
    cards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            anime({
                targets: this,
                translateY: -8,
                boxShadow: '0 20px 40px rgba(0, 0, 0, 0.3)',
                duration: 300,
                easing: 'easeOutQuad'
            });
        });
        
        card.addEventListener('mouseleave', function() {
            anime({
                targets: this,
                translateY: 0,
                boxShadow: '0 0 0 rgba(0, 0, 0, 0)',
                duration: 300,
                easing: 'easeOutQuad'
            });
        });
    });
    
    // Button hover effects
    const buttons = document.querySelectorAll('.btn-primary, .btn-secondary');
    buttons.forEach(button => {
        button.addEventListener('mouseenter', function() {
            anime({
                targets: this,
                translateY: -2,
                duration: 200,
                easing: 'easeOutQuad'
            });
        });
        
        button.addEventListener('mouseleave', function() {
            anime({
                targets: this,
                translateY: 0,
                duration: 200,
                easing: 'easeOutQuad'
            });
        });
    });
}

// Scroll Effects
function initializeScrollEffects() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const element = entry.target;
                
                if (element.classList.contains('feature-card')) {
                    anime({
                        targets: element,
                        translateY: [50, 0],
                        opacity: [0, 1],
                        duration: 600,
                        easing: 'easeOutQuad',
                        delay: Math.random() * 200
                    });
                }
                
                if (element.classList.contains('timeline-item')) {
                    anime({
                        targets: element,
                        translateX: [-30, 0],
                        opacity: [0, 1],
                        duration: 500,
                        easing: 'easeOutQuad'
                    });
                }
                
                observer.unobserve(element);
            }
        });
    }, observerOptions);
    
    // Observe elements for scroll animations
    document.querySelectorAll('.feature-card, .timeline-item').forEach(el => {
        el.style.opacity = '0';
        observer.observe(el);
    });
}

// Utility Functions
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `fixed top-20 right-4 p-4 rounded-lg shadow-lg z-50 ${
        type === 'success' ? 'bg-green-600' : 
        type === 'error' ? 'bg-red-600' : 
        'bg-blue-600'
    } text-white`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // Animate in
    anime({
        targets: notification,
        translateX: [300, 0],
        opacity: [0, 1],
        duration: 300,
        easing: 'easeOutQuad'
    });
    
    // Remove after 3 seconds
    setTimeout(() => {
        anime({
            targets: notification,
            translateX: [0, 300],
            opacity: [1, 0],
            duration: 300,
            easing: 'easeInQuad',
            complete: () => {
                document.body.removeChild(notification);
            }
        });
    }, 3000);
}

// Button Click Handlers
document.addEventListener('click', function(e) {
    if (e.target.matches('.btn-primary') || e.target.matches('.btn-secondary')) {
        const buttonText = e.target.textContent.trim();
        
        switch(buttonText) {
            case 'Access Platform':
            case 'Demo':
            case 'Start Demo':
            case 'Learn More':
                showNotification('Coming Soon - Platform access will be available in Q1 2024', 'info');
                break;
            case 'View Demo':
                showNotification('Interactive demo will be available soon', 'info');
                break;
            default:
                showNotification('Feature coming soon', 'info');
        }
    }
});

// Navigation Click Handlers
document.addEventListener('click', function(e) {
    if (e.target.matches('nav a')) {
        e.preventDefault();
        const linkText = e.target.textContent.trim();
        
        if (linkText === 'Trading Command Center Grid OPs') {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        } else {
            showNotification(`${linkText} page coming soon`, 'info');
        }
    }
});

// Smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Add loading animation
window.addEventListener('load', function() {
    // Hide any loading indicators
    const loader = document.querySelector('.loader');
    if (loader) {
        anime({
            targets: loader,
            opacity: [1, 0],
            duration: 500,
            complete: () => {
                loader.style.display = 'none';
            }
        });
    }
    
    // Initialize any additional animations
    setTimeout(() => {
        initializeAnimations();
    }, 100);
});

// Mobile menu toggle (if needed)
function toggleMobileMenu() {
    const mobileMenu = document.getElementById('mobileMenu');
    if (mobileMenu) {
        mobileMenu.classList.toggle('hidden');
    }
}

// Performance monitoring
const performanceObserver = new PerformanceObserver((list) => {
    for (const entry of list.getEntries()) {
        if (entry.entryType === 'measure') {
            console.log(`${entry.name}: ${entry.duration}ms`);
        }
    }
});

if (typeof PerformanceObserver !== 'undefined') {
    performanceObserver.observe({ entryTypes: ['measure'] });
}

// Error handling
window.addEventListener('error', function(e) {
    console.error('JavaScript error:', e.error);
    // Could send error to analytics service
});

// Unhandled promise rejection handling
window.addEventListener('unhandledrejection', function(e) {
    console.error('Unhandled promise rejection:', e.reason);
    // Could send error to analytics service
});

// Export functions for potential external use
window.GridBotCC = {
    showNotification,
    toggleMobileMenu,
    initializeGridVisualizer,
    initializeTimeline
};