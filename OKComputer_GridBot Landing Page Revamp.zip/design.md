# GridBot Command Center - Design Style Guide

## Design Philosophy

### Visual Language
- **Professional Authority**: Institutional-grade aesthetic that conveys trust and competence
- **Technical Precision**: Clean, engineering-focused design that reflects systematic approach
- **Sophisticated Minimalism**: Refined restraint that prioritizes clarity over decoration
- **Dark Elegance**: Professional dark theme suitable for extended trading sessions

### Color Palette
- **Primary Background**: Deep charcoal (#1a1a1a) - professional, reduces eye strain
- **Secondary Background**: Darker graphite (#0f0f0f) - creates depth and hierarchy
- **Accent Primary**: Muted teal (#2dd4bf) - trust, stability, financial growth
- **Accent Secondary**: Warm amber (#f59e0b) - attention, warnings, highlights
- **Text Primary**: Pure white (#ffffff) - maximum contrast for readability
- **Text Secondary**: Light gray (#a3a3a3) - supporting information
- **Success**: Forest green (#059669) - profits, positive metrics
- **Risk**: Muted red (#dc2626) - losses, risk indicators
- **Grid Lines**: Subtle gray (#374151) - structure without distraction

### Typography
- **Display Font**: "Inter" - Clean, technical, highly legible for headings
- **Body Font**: "Inter" - Consistent family for optimal readability
- **Monospace**: "JetBrains Mono" - For numbers, data, and code-like elements
- **Font Hierarchy**: 
  - H1: 3rem (48px) - Bold, hero statements
  - H2: 2.25rem (36px) - Section headers
  - H3: 1.5rem (24px) - Subsection titles
  - Body: 1rem (16px) - Standard text
  - Small: 0.875rem (14px) - Supporting details

## Visual Effects & Styling

### Used Libraries & Effects
- **ECharts.js**: Interactive price charts with grid visualization
- **Anime.js**: Smooth micro-interactions and state transitions
- **Shader-park**: Subtle background particle effects representing market data
- **Pixi.js**: High-performance grid animation overlays
- **Splide.js**: Feature showcase carousels

### Animation Strategy
- **Micro-interactions**: Subtle hover states on interactive elements
- **Data Visualization**: Smooth chart animations that build understanding
- **State Transitions**: Professional fade/slide transitions between content sections
- **Loading States**: Elegant skeleton screens for data-heavy components

### Header & Hero Effects
- **Background**: Animated particle field representing market data points
- **Grid Overlay**: Subtle geometric pattern suggesting order structure
- **Typography**: Large, bold headings with subtle glow effects
- **Charts**: Real-time animated price charts showing grid strategy in action

### Interactive Elements
- **Buttons**: Solid backgrounds with subtle depth and hover elevation
- **Cards**: Clean borders with shadow depth on hover
- **Form Elements**: Minimal styling with focus states using accent colors
- **Data Displays**: Clean tables and metrics with clear hierarchy

### Layout Principles
- **Grid System**: 12-column responsive grid for consistent alignment
- **Whitespace**: Generous spacing for clarity and focus
- **Sections**: Clear visual separation without harsh dividers
- **Responsive**: Mobile-first approach with progressive enhancement

### Component Styling
- **Navigation**: Fixed dark header with subtle transparency
- **Charts**: Dark backgrounds with bright data visualization
- **Cards**: Subtle borders with hover elevation
- **Forms**: Clean inputs with clear labels and validation states
- **Tables**: Alternating row colors for readability

### Accessibility Considerations
- **Contrast Ratios**: Minimum 4.5:1 for all text elements
- **Focus States**: Clear keyboard navigation indicators
- **Color Independence**: Information conveyed through multiple visual cues
- **Motion**: Respects user preferences for reduced motion

## Brand Personality
- **Trustworthy**: Institutional-grade design that inspires confidence
- **Sophisticated**: Refined aesthetic that appeals to serious traders
- **Systematic**: Clean, organized layout that reflects methodical approach
- **Professional**: Business-focused design suitable for enterprise users