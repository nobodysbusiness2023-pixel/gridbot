<?php
/**
 * The main template file for GridBot Command Center
 *
 * @package GridBot_Command_Center
 */

get_header();

// Include the main landing page content
get_template_part('template-parts/landing-page');

get_footer();
?>