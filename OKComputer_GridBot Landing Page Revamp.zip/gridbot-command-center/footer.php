    </div><!-- #page-wrapper -->
    
    <!-- Footer -->
    <footer class="footer-3d" id="main-footer">
        <div class="footer-background">
            <div class="footer-particles" id="footer-particles"></div>
        </div>
        
        <div class="footer-content">
            <div class="footer-section footer-brand">
                <div class="footer-logo">
                    <h2>GridBot<span class="text-primary">CC</span></h2>
                    <p class="footer-description">
                        Professional-grade grid trading control platform for systematic strategy execution
                    </p>
                </div>
                
                <div class="footer-social">
                    <a href="#" class="social-link" aria-label="Twitter">
                        <svg class="social-icon" viewBox="0 0 24 24">
                            <path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z"/>
                        </svg>
                    </a>
                    <a href="#" class="social-link" aria-label="Discord">
                        <svg class="social-icon" viewBox="0 0 24 24">
                            <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 012.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028 14.09 14.09 0 0 0 1.226-1.994.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.662a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"/>
                        </svg>
                    </a>
                    <a href="#" class="social-link" aria-label="Telegram">
                        <svg class="social-icon" viewBox="0 0 24 24">
                            <path d="M23.91 3.79L20.32 20.2c-.36 1.86-1.57 2.33-3.18 1.45l-6.4-4.73-3.1 2.95c-.34.33-.63.61-1.29.61l.46-6.5 11.86-10.74c.52-.48-.12-.75-.8-.26L5.6 13.87l-5.47-1.7c-1.8-.56-1.83-1.8.38-2.65L22.24 2.53c1.74-.64 1.74 1.1.67 1.26z"/>
                        </svg>
                    </a>
                </div>
            </div>
            
            <div class="footer-section footer-links">
                <h4>Platform</h4>
                <ul class="footer-nav">
                    <li><a href="#features">Features</a></li>
                    <li><a href="#how-it-works">How It Works</a></li>
                    <li><a href="#pricing">Pricing</a></li>
                    <li><a href="#documentation">Documentation</a></li>
                </ul>
            </div>
            
            <div class="footer-section footer-links">
                <h4>Resources</h4>
                <ul class="footer-nav">
                    <li><a href="#blog">Blog</a></li>
                    <li><a href="#tutorials">Tutorials</a></li>
                    <li><a href="#api">API Reference</a></li>
                    <li><a href="#support">Support</a></li>
                </ul>
            </div>
            
            <div class="footer-section footer-links">
                <h4>Legal</h4>
                <ul class="footer-nav">
                    <li><a href="#privacy">Privacy Policy</a></li>
                    <li><a href="#terms">Terms of Service</a></li>
                    <li><a href="#risk">Risk Disclosure</a></li>
                    <li><a href="#contact">Contact</a></li>
                </ul>
            </div>
        </div>
        
        <div class="footer-bottom">
            <div class="footer-bottom-content">
                <div class="footer-copyright">
                    <p>&copy; <?php echo date('Y'); ?> GridBot Command Center. All rights reserved.</p>
                </div>
                
                <div class="footer-disclaimer">
                    <p>
                        <strong>Risk Warning:</strong> This is a professional trading tool. Not a signal service. 
                        Not AI prediction software. Not a guarantee of profits. Trade responsibly. 
                        Only deploy capital you can afford to lose. Cryptocurrency trading involves substantial risk of loss.
                    </p>
                </div>
                
                <div class="footer-performance">
                    <div class="performance-metrics" id="footer-performance-metrics">
                        <!-- Performance metrics will be populated by JavaScript -->
                    </div>
                </div>
            </div>
        </div>
    </footer>
    
    <!-- Back to Top Button -->
    <button class="back-to-top" id="back-to-top" aria-label="Back to top">
        <svg class="back-to-top-icon" viewBox="0 0 24 24">
            <path d="M7 14l5-5 5 5z"/>
        </svg>
    </button>
    
    <!-- Performance Overlay -->
    <div class="performance-overlay" id="performance-overlay">
        <div class="performance-content">
            <h4>Performance Metrics</h4>
            <div class="performance-stats" id="performance-stats">
                <!-- Stats will be populated by JavaScript -->
            </div>
            <button class="performance-close" id="performance-close">&times;</button>
        </div>
    </div>
    
    <!-- WordPress Footer -->
    <?php wp_footer(); ?>
    
    <!-- Performance Monitoring -->
    <script>
        // Mark footer end for performance monitoring
        if (window.performance) {
            window.performance.mark('theme-footer-end');
            window.performance.measure('theme-total-load', 'theme-head-start', 'theme-footer-end');
        }
        
        // Initialize footer animations
        document.addEventListener('DOMContentLoaded', function() {
            // Animate footer on scroll
            const footer = document.getElementById('main-footer');
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        anime({
                            targets: entry.target.querySelector('.footer-content'),
                            translateY: [50, 0],
                            opacity: [0, 1],
                            duration: 800,
                            easing: 'easeOutQuad'
                        });
                    }
                });
            });
            
            if (footer) {
                observer.observe(footer);
            }
            
            // Back to top functionality
            const backToTop = document.getElementById('back-to-top');
            if (backToTop) {
                backToTop.addEventListener('click', function(e) {
                    e.preventDefault();
                    window.scrollTo({
                        top: 0,
                        behavior: 'smooth'
                    });
                });
                
                // Show/hide back to top button
                window.addEventListener('scroll', function() {
                    if (window.scrollY > 500) {
                        backToTop.classList.add('visible');
                    } else {
                        backToTop.classList.remove('visible');
                    }
                });
            }
            
            // Performance overlay toggle
            const performanceOverlay = document.getElementById('performance-overlay');
            const performanceClose = document.getElementById('performance-close');
            
            if (performanceOverlay && performanceClose) {
                performanceClose.addEventListener('click', function() {
                    performanceOverlay.classList.remove('active');
                });
                
                performanceOverlay.addEventListener('click', function(e) {
                    if (e.target === performanceOverlay) {
                        performanceOverlay.classList.remove('active');
                    }
                });
            }
        });
    </script>
    
    <!-- Additional Scripts -->
    <script src="<?php echo get_template_directory_uri(); ?>/assets/js/footer-animations.js"></script>
</body>
</html>