<?php
/**
 * GridBot Command Center Theme Functions
 * 
 * @package GridBot_Command_Center
 * @version 2.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

// Theme Version
define('GRIDBOTCC_VERSION', '2.0.0');
define('GRIDBOTCC_DIR', get_template_directory());
define('GRIDBOTCC_URI', get_template_directory_uri());

/**
 * Theme Setup
 */
function gridbotcc_setup() {
    // Add theme support
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption'));
    add_theme_support('customize-selective-refresh-widgets');
    add_theme_support('editor-styles');
    add_theme_support('responsive-embeds');
    
    // Register navigation menus
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'gridbot-command-center'),
        'footer' => __('Footer Menu', 'gridbot-command-center'),
    ));
    
    // Set content width
    if (!isset($content_width)) {
        $content_width = 1200;
    }
}
add_action('after_setup_theme', 'gridbotcc_setup');

/**
 * Enqueue Scripts and Styles
 */
function gridbotcc_scripts() {
    // Main stylesheet
    wp_enqueue_style('gridbotcc-style', get_stylesheet_uri(), array(), GRIDBOTCC_VERSION);
    
    // Custom CSS
    wp_enqueue_style('gridbotcc-custom', GRIDBOTCC_URI . '/assets/css/custom.css', array(), GRIDBOTCC_VERSION);
    
    // Google Fonts
    wp_enqueue_style('gridbotcc-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap', array(), null);
    
    // 3D Libraries
    wp_enqueue_script('three-js', 'https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js', array(), 'r128', true);
    wp_enqueue_script('anime-js', 'https://cdnjs.cloudflare.com/ajax/libs/animejs/3.2.1/anime.min.js', array(), '3.2.1', true);
    wp_enqueue_script('pixi-js', 'https://cdnjs.cloudflare.com/ajax/libs/pixi.js/7.2.4/pixi.min.js', array(), '7.2.4', true);
    wp_enqueue_script('matter-js', 'https://cdnjs.cloudflare.com/ajax/libs/matter-js/0.19.0/matter.min.js', array(), '0.19.0', true);
    wp_enqueue_script('echarts-js', 'https://cdn.jsdelivr.net/npm/echarts@5.4.3/dist/echarts.min.js', array(), '5.4.3', true);
    wp_enqueue_script('splide-js', 'https://cdn.jsdelivr.net/npm/@splidejs/splide@4.1.4/dist/js/splide.min.js', array(), '4.1.4', true);
    wp_enqueue_style('splide-css', 'https://cdn.jsdelivr.net/npm/@splidejs/splide@4.1.4/dist/css/splide.min.css', array(), '4.1.4');
    
    // Main JavaScript
    wp_enqueue_script('gridbotcc-main', GRIDBOTCC_URI . '/assets/js/main.js', array('jquery', 'three-js', 'anime-js'), GRIDBOTCC_VERSION, true);
    
    // 3D Scene JavaScript
    wp_enqueue_script('gridbotcc-3d', GRIDBOTCC_URI . '/assets/js/3d-scenes.js', array('three-js', 'pixi-js', 'matter-js'), GRIDBOTCC_VERSION, true);
    
    // Particle System
    wp_enqueue_script('gridbotcc-particles', GRIDBOTCC_URI . '/assets/js/particles.js', array('pixi-js'), GRIDBOTCC_VERSION, true);
    
    // Trading Visualizer
    wp_enqueue_script('gridbotcc-trading', GRIDBOTCC_URI . '/assets/js/trading-3d.js', array('echarts-js', 'three-js'), GRIDBOTCC_VERSION, true);
    
    // Localize script data
    wp_localize_script('gridbotcc-main', 'gridbotccData', array(
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'themeUri' => GRIDBOTCC_URI,
        'isHome' => is_front_page(),
        'isUserLoggedIn' => is_user_logged_in(),
    ));
    
    // Comment reply script
    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
}
add_action('wp_enqueue_scripts', 'gridbotcc_scripts');

/**
 * Register Sidebars/Widget Areas
 */
function gridbotcc_widgets_init() {
    register_sidebar(array(
        'name' => __('Primary Sidebar', 'gridbot-command-center'),
        'id' => 'primary-sidebar',
        'description' => __('Main sidebar area', 'gridbot-command-center'),
        'before_widget' => '<div id="%1$s" class="widget %2$s card-3d">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ));
    
    register_sidebar(array(
        'name' => __('Footer Widgets', 'gridbot-command-center'),
        'id' => 'footer-widgets',
        'description' => __('Footer widget area', 'gridbot-command-center'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h4 class="widget-title">',
        'after_title' => '</h4>',
    ));
}
add_action('widgets_init', 'gridbotcc_widgets_init');

/**
 * Custom Post Types
 */
function gridbotcc_register_post_types() {
    // Grid Strategies Post Type
    register_post_type('grid_strategies', array(
        'labels' => array(
            'name' => __('Grid Strategies', 'gridbot-command-center'),
            'singular_name' => __('Grid Strategy', 'gridbot-command-center'),
        ),
        'public' => true,
        'has_archive' => true,
        'rewrite' => array('slug' => 'strategies'),
        'supports' => array('title', 'editor', 'thumbnail', 'excerpt'),
        'menu_icon' => 'dashicons-chart-line',
    ));
    
    // Trading Pairs Post Type
    register_post_type('trading_pairs', array(
        'labels' => array(
            'name' => __('Trading Pairs', 'gridbot-command-center'),
            'singular_name' => __('Trading Pair', 'gridbot-command-center'),
        ),
        'public' => true,
        'has_archive' => true,
        'rewrite' => array('slug' => 'pairs'),
        'supports' => array('title', 'editor', 'thumbnail'),
        'menu_icon' => 'dashicons-money-alt',
    ));
    
    // Performance Data Post Type
    register_post_type('performance_data', array(
        'labels' => array(
            'name' => __('Performance Data', 'gridbot-command-center'),
            'singular_name' => __('Performance Record', 'gridbot-command-center'),
        ),
        'public' => true,
        'has_archive' => true,
        'rewrite' => array('slug' => 'performance'),
        'supports' => array('title', 'editor', 'custom-fields'),
        'menu_icon' => 'dashicons-performance',
    ));
}
add_action('init', 'gridbotcc_register_post_types');

/**
 * Custom Taxonomies
 */
function gridbotcc_register_taxonomies() {
    // Strategy Categories
    register_taxonomy('strategy_category', 'grid_strategies', array(
        'labels' => array(
            'name' => __('Strategy Categories', 'gridbot-command-center'),
            'singular_name' => __('Strategy Category', 'gridbot-command-center'),
        ),
        'hierarchical' => true,
        'public' => true,
        'rewrite' => array('slug' => 'strategy-category'),
    ));
    
    // Market Conditions
    register_taxonomy('market_condition', array('grid_strategies', 'performance_data'), array(
        'labels' => array(
            'name' => __('Market Conditions', 'gridbot-command-center'),
            'singular_name' => __('Market Condition', 'gridbot-command-center'),
        ),
        'hierarchical' => false,
        'public' => true,
    ));
}
add_action('init', 'gridbotcc_register_taxonomies');

/**
 * Custom Shortcodes
 */
function gridbotcc_register_shortcodes() {
    // 3D Trading Visualizer
    add_shortcode('gridbot_3d_visualizer', 'gridbotcc_3d_visualizer_shortcode');
    
    // Particle System
    add_shortcode('gridbot_particles', 'gridbotcc_particles_shortcode');
    
    // 3D Feature Cards
    add_shortcode('gridbot_feature_cards', 'gridbotcc_feature_cards_shortcode');
    
    // Trading Calculator
    add_shortcode('gridbot_calculator', 'gridbotcc_calculator_shortcode');
    
    // Performance Chart
    add_shortcode('gridbot_performance_chart', 'gridbotcc_performance_chart_shortcode');
}
add_action('init', 'gridbotcc_register_shortcodes');

/**
 * 3D Visualizer Shortcode
 */
function gridbotcc_3d_visualizer_shortcode($atts) {
    $atts = shortcode_atts(array(
        'width' => '100%',
        'height' => '400px',
        'theme' => 'dark',
    ), $atts);
    
    ob_start();
    ?>
    <div class="gridbot-3d-visualizer" 
         data-width="<?php echo esc_attr($atts['width']); ?>" 
         data-height="<?php echo esc_attr($atts['height']); ?>" 
         data-theme="<?php echo esc_attr($atts['theme']); ?>">
        <div id="three-canvas-container" class="three-canvas-container"></div>
        <div class="visualizer-controls">
            <button class="btn btn-primary" id="play-animation">Play Animation</button>
            <button class="btn btn-secondary" id="reset-view">Reset View</button>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

/**
 * Particles Shortcode
 */
function gridbotcc_particles_shortcode($atts) {
    $atts = shortcode_atts(array(
        'count' => '1000',
        'speed' => '1',
        'color' => '#2dd4bf',
    ), $atts);
    
    ob_start();
    ?>
    <div class="gridbot-particles" 
         data-count="<?php echo esc_attr($atts['count']); ?>" 
         data-speed="<?php echo esc_attr($atts['speed']); ?>" 
         data-color="<?php echo esc_attr($atts['color']); ?>">
        <canvas id="particle-canvas"></canvas>
    </div>
    <?php
    return ob_get_clean();
}

/**
 * Feature Cards Shortcode
 */
function gridbotcc_feature_cards_shortcode($atts) {
    $atts = shortcode_atts(array(
        'category' => '',
        'count' => '6',
    ), $atts);
    
    ob_start();
    ?>
    <div class="gridbot-feature-cards" data-category="<?php echo esc_attr($atts['category']); ?>">
        <div class="feature-cards-grid" id="feature-cards-container">
            <!-- Cards will be populated by JavaScript -->
        </div>
    </div>
    <?php
    return ob_get_clean();
}

/**
 * Trading Calculator Shortcode
 */
function gridbotcc_calculator_shortcode($atts) {
    ob_start();
    ?>
    <div class="gridbot-calculator card-3d">
        <h3>Grid Trading Calculator</h3>
        <div class="calculator-form">
            <div class="form-group">
                <label for="capital">Capital Amount ($)</label>
                <input type="number" id="capital" placeholder="10000" class="form-control">
            </div>
            <div class="form-group">
                <label for="grid-range">Grid Range (%)</label>
                <input type="number" id="grid-range" placeholder="10" class="form-control">
            </div>
            <div class="form-group">
                <label for="grid-count">Number of Grids</label>
                <input type="number" id="grid-count" placeholder="10" class="form-control">
            </div>
            <button class="btn btn-primary" id="calculate-profit">Calculate Potential Profit</button>
        </div>
        <div class="calculator-results" id="calculator-results"></div>
    </div>
    <?php
    return ob_get_clean();
}

/**
 * Performance Chart Shortcode
 */
function gridbotcc_performance_chart_shortcode($atts) {
    $atts = shortcode_atts(array(
        'width' => '100%',
        'height' => '300px',
        'period' => '30d',
    ), $atts);
    
    ob_start();
    ?>
    <div class="gridbot-performance-chart" 
         data-width="<?php echo esc_attr($atts['width']); ?>" 
         data-height="<?php echo esc_attr($atts['height']); ?>" 
         data-period="<?php echo esc_attr($atts['period']); ?>">
        <div id="performance-chart-container"></div>
    </div>
    <?php
    return ob_get_clean();
}

/**
 * Customizer Settings
 */
function gridbotcc_customizer($wp_customize) {
    // 3D Settings Section
    $wp_customize->add_section('gridbotcc_3d_settings', array(
        'title' => __('3D Settings', 'gridbot-command-center'),
        'priority' => 30,
    ));
    
    // Enable 3D Effects
    $wp_customize->add_setting('gridbotcc_enable_3d', array(
        'default' => true,
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('gridbotcc_enable_3d', array(
        'label' => __('Enable 3D Effects', 'gridbot-command-center'),
        'section' => 'gridbotcc_3d_settings',
        'type' => 'checkbox',
    ));
    
    // Particle Count
    $wp_customize->add_setting('gridbotcc_particle_count', array(
        'default' => '1000',
        'sanitize_callback' => 'absint',
    ));
    
    $wp_customize->add_control('gridbotcc_particle_count', array(
        'label' => __('Particle Count', 'gridbot-command-center'),
        'section' => 'gridbotcc_3d_settings',
        'type' => 'number',
        'input_attrs' => array(
            'min' => 100,
            'max' => 5000,
            'step' => 100,
        ),
    ));
    
    // Animation Speed
    $wp_customize->add_setting('gridbotcc_animation_speed', array(
        'default' => '1.0',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('gridbotcc_animation_speed', array(
        'label' => __('Animation Speed', 'gridbot-command-center'),
        'section' => 'gridbotcc_3d_settings',
        'type' => 'range',
        'input_attrs' => array(
            'min' => '0.1',
            'max' => '3.0',
            'step' => '0.1',
        ),
    ));
}
add_action('customize_register', 'gridbotcc_customizer');

/**
 * Admin Notice for Theme Features
 */
function gridbotcc_admin_notice() {
    global $pagenow;
    if ($pagenow == 'themes.php') {
        ?>
        <div class="notice notice-success is-dismissible">
            <p><strong>GridBot Command Center Theme Activated!</strong></p>
            <p>Your 3D-enabled trading platform theme is now active. Use the shortcodes to add interactive elements:</p>
            <ul style="list-style: disc; margin-left: 20px;">
                <li><code>[gridbot_3d_visualizer]</code> - 3D Trading Visualizer</li>
                <li><code>[gridbot_particles]</code> - Particle System Background</li>
                <li><code>[gridbot_feature_cards]</code> - 3D Feature Cards</li>
                <li><code>[gridbot_calculator]</code> - Trading Calculator</li>
                <li><code>[gridbot_performance_chart]</code> - Performance Chart</li>
            </ul>
            <p>Customize 3D settings in Appearance > Customize > 3D Settings</p>
        </div>
        <?php
    }
}
add_action('admin_notices', 'gridbotcc_admin_notice');

/**
 * Performance Optimization
 */
function gridbotcc_optimize_performance() {
    // Remove WordPress emoji scripts
    remove_action('wp_head', 'print_emoji_detection_script', 7);
    remove_action('wp_print_styles', 'print_emoji_styles');
    
    // Remove WordPress version number
    remove_action('wp_head', 'wp_generator');
    
    // Remove wlwmanifest link
    remove_action('wp_head', 'wlwmanifest_link');
    
    // Remove RSD link
    remove_action('wp_head', 'rsd_link');
    
    // Remove shortlink
    remove_action('wp_head', 'wp_shortlink_wp_head');
    
    // Remove feed links
    remove_action('wp_head', 'feed_links', 2);
    remove_action('wp_head', 'feed_links_extra', 3);
}
add_action('init', 'gridbotcc_optimize_performance');

/**
 * Security Headers
 */
function gridbotcc_security_headers() {
    if (!is_admin()) {
        header("X-Frame-Options: SAMEORIGIN");
        header("X-Content-Type-Options: nosniff");
        header("X-XSS-Protection: 1; mode=block");
        header("Referrer-Policy: strict-origin-when-cross-origin");
    }
}
add_action('send_headers', 'gridbotcc_security_headers');

/**
 * Theme Activation Hook
 */
function gridbotcc_theme_activation() {
    // Flush rewrite rules
    flush_rewrite_rules();
    
    // Set default options
    if (!get_option('gridbotcc_particle_count')) {
        update_option('gridbotcc_particle_count', 1000);
    }
    
    if (!get_option('gridbotcc_animation_speed')) {
        update_option('gridbotcc_animation_speed', 1.0);
    }
}
add_action('after_switch_theme', 'gridbotcc_theme_activation');

/**
 * Theme Deactivation Hook
 */
function gridbotcc_theme_deactivation() {
    flush_rewrite_rules();
}
add_action('switch_theme', 'gridbotcc_theme_deactivation');

// Include additional files
require_once GRIDBOTCC_DIR . '/inc/custom-post-types.php';
require_once GRIDBOTCC_DIR . '/inc/shortcodes.php';
require_once GRIDBOTCC_DIR . '/inc/3d-renderer.php';
require_once GRIDBOTCC_DIR . '/inc/admin-functions.php';

/**
 * Helper Functions
 */
function gridbotcc_get_theme_option($key, $default = '') {
    return get_theme_mod($key, $default);
}

function gridbotcc_is_3d_enabled() {
    return gridbotcc_get_theme_option('gridbotcc_enable_3d', true);
}

function gridbotcc_get_particle_count() {
    return gridbotcc_get_theme_option('gridbotcc_particle_count', 1000);
}

function gridbotcc_get_animation_speed() {
    return gridbotcc_get_theme_option('gridbotcc_animation_speed', 1.0);
}